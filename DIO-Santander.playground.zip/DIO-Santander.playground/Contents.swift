import UIKit

//constante
let name = "Steve";

//variavel opcional
var lastName: String? = "Jobs";

print("\(name) \(lastName ?? "Woszniak")");

if let lastName = lastName {
    print("\(name) \(lastName)");
}


